﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace To_Do_List
{
    class Tasks
    {
        private List<TaskDetails> taskdetails;

        //Getters and Setters
        public List<TaskDetails> TaskDetails
        { get; set; }

        public string TaskName
        { get; set; }

        //Constructor
        public Tasks(string taskName, List<TaskDetails> moduledetails)
        {
            this.TaskDetails = moduledetails;
            this.TaskName = taskName;

        }
    }
}
