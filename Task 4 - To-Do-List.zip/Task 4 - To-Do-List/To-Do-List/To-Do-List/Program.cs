﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace To_Do_List
{
    class Program
    {
        static Tasks CreateTask() //Method the captures user input
        {

            Console.WriteLine("Enter the name of the Task:");
            string taskName = Console.ReadLine();

            List<TaskDetails> taskdetails = new List<TaskDetails>();

            Console.WriteLine("Enter the Task ID:");
            int taskId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Duration of the Task:");
            string duration = Console.ReadLine();

            Console.WriteLine("Enter the Status of the Task (Pending or Complete):");
            string status = Console.ReadLine();


            TaskDetails task = new TaskDetails(taskId, duration, status);
            taskdetails.Add(task);

            return new Tasks(taskName, taskdetails); //return task name and the task details captured
        }

        static void DisplayTasks(List<Tasks> takss) //Method that displays the captured information
        {

            if (takss.Count == 0)
            {
                Console.WriteLine("No Tasks Found");
                return;
            }

            Console.WriteLine("Select Task");

            for (int i = 0; i < takss.Count; i++)
            {
                Console.WriteLine((i + 1) + ": " + takss[i].TaskName);
            }

            int choice = int.Parse(Console.ReadLine());

            if (choice < 1 || choice > takss.Count)
            {
                Console.WriteLine("Invalid Choice");
            }

            Tasks selectedTask = takss[choice - 1];

            Console.WriteLine("------------------------------");
            Console.WriteLine("Task Name: " + selectedTask.TaskName);
            Console.WriteLine("Task Details:");
            Console.WriteLine(" ");

            foreach (TaskDetails task in selectedTask.TaskDetails)
            {
                Console.WriteLine("Task ID: " + task.TaskId + "\n" +
                                             "Task Duration: " + task.Duration + "\n" +
                                             "Task Status: " + task.Status);
                Console.WriteLine("------------------------------");
                Console.WriteLine("");

            }

            Console.WriteLine("If Task: (" + selectedTask.TaskName + ") is complete enter 1 , else, enter 2 to return to Main Menu");
            int choice2 = int.Parse(Console.ReadLine());

            switch (choice2)
            {
                case 1:
                   foreach(TaskDetails task in selectedTask.TaskDetails)
                      {
                        task.Status = "Completed";
                      }
                break;

                case 2:

                    break;
            }
           
        }

        static void DeleteTask(List<Tasks> tasks,int taskId)
        {
           // Find the task in the list with matching taskId

            Tasks taskToDelete = tasks.Find(t => t.TaskDetails.Any(td => td.TaskId == taskId));
            if (taskToDelete != null)
            {
                tasks.Remove(taskToDelete);
                Console.WriteLine("Task with this  ID (" + taskId + ") has been deleted successfully.");
            }
            else
            {
                Console.WriteLine("Task with this ID (" + taskId + ") not found, enter a valid ID.");
                Console.WriteLine("");
            }

        }

        static void Menu() //Menu that the user will choose from
        {
            Console.WriteLine("-------------------");
            Console.WriteLine("1 - Add Task");
            Console.WriteLine("2 - Disiplay Tasks");
            Console.WriteLine("3 - Delete Task");
            Console.WriteLine("4 - Exit Program");
            Console.WriteLine(" ");
            Console.WriteLine("Enter Your choice");
            Console.WriteLine("-------------------");
            
        }

        static void Main(string[] args)
        {

            List<Tasks> takss = new List<Tasks>();

            Console.WriteLine("Welcome to the Task Manager");
            Console.WriteLine("");

            bool running = true;
            while (running)
            {
                Menu(); //Calls the Menu Method with options to choose from.

                int choice = int.Parse(Console.ReadLine());

                switch (choice) //Switch statement that calls different methods 
                {
                    case 1:
                        Tasks task = CreateTask(); //Calls the Add tasks method
                        takss.Add(task);
                        Console.WriteLine("Task Successfully Added");
                        Console.WriteLine("");
                        break;

                    case 2:
                        takss = takss.OrderBy(r => r.TaskName).ToList(); //Display the Task in Alphabetical Order 
                        DisplayTasks(takss); //Calls the display tasks method
                        break;

                    case 3:
                       // Prompt user to enter the task ID to delete
                        Console.WriteLine("Enter the ID of the Task to delete:");
                        int taskIdToDelete = int.Parse(Console.ReadLine());
                        DeleteTask(takss,taskIdToDelete);
                        break;

                    case 4:
                        running = false; //If user option is 4, program will terminate
                        break;

                    default:
                        Console.WriteLine("Invalid Option , Try Again");
                        break;


                }
            }
        }
    }
}
