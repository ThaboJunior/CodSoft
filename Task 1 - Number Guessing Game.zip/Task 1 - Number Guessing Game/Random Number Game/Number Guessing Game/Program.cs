﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Number_Guessing_Game
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Random Number Guessing Game");
            Console.WriteLine("");

            //initiating a random number generator
            Random random = new Random();

            //This code will generate a random number between 1 and 100
            int randomNumber = random.Next(1, 100);

            //this variable will store user input
            int users_Guess;

           
            do
            {
                Console.WriteLine("Enter a number between 1 and 100.");

                // prompts the user to enter a number and ensures its valid
                while (!int.TryParse(Console.ReadLine(), out users_Guess))
                {
                    Console.WriteLine("Invalid input. Please enter a valid number." + "\n" +
                        "Enter a number between 1 and 100.");
                   
                }


                if (users_Guess == randomNumber)
                {
                    Console.WriteLine("Congratulations!!! You guessed the correct number");
                }
                else if (users_Guess < randomNumber)
                {
                    Console.WriteLine("Too low, Try again.");
                }
                else
                {
                    Console.WriteLine("Too high, Try again.");
                }

            } while (users_Guess != randomNumber);

            Console.ReadLine(); // To keep the console window open

        }
    }
}
